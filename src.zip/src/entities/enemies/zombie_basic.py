import pygame

from src.entities.enemies.base_enemy import BaseEnemy
from src.systems.asset_system import AssetManager


class ZombieBase(BaseEnemy):

    # =========================================================
    # SHARED ASSETS
    # =========================================================

    SPRITE_SHEET = None

    FRAMES = []

    RIGHT_ARM = None

    # =========================================================
    # INIT
    # =========================================================

    def __init__(self, game, x, y):

        super().__init__(game, x, y)

        # =====================================================
        # STATS
        # =====================================================

        self.speed = 1

        self.contact_damage = 10

        self.max_hp = 100

        self.hp = self.max_hp

        # =====================================================
        # GORE
        # =====================================================

        self.right_arm_removed = False

        # =====================================================
        # LOAD SPRITES
        # =====================================================

        if ZombieBase.SPRITE_SHEET is None:

            ZombieBase.SPRITE_SHEET = AssetManager.load_image(
                "assets/sprites/monsters/"
                "zombie_basic/"
                "zombie_basic.png"
            )

        if ZombieBase.RIGHT_ARM is None:

            ZombieBase.RIGHT_ARM = AssetManager.load_image(
                "assets/sprites/monsters/"
                "zombie_basic/"
                "zombie_basic_right_arm.png"
            )

        # =====================================================
        # ANIMATION
        # =====================================================

        self.frame_index = 0

        self.animation_speed = 0.15

        if not ZombieBase.FRAMES:

            frame_width = 96

            frame_height = 96

            for i in range(8):

                frame = ZombieBase.SPRITE_SHEET.subsurface(

                    (
                        i * frame_width,
                        0,
                        frame_width,
                        frame_height
                    )
                )

                frame = pygame.transform.scale(
                    frame,
                    (48, 48)
                )

                ZombieBase.FRAMES.append(frame)

        self.frames = ZombieBase.FRAMES