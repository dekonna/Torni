import pygame


class BodyPart:

    def __init__(
        self,
        game,
        x,
        y,
        image,
        velocity_x,
        velocity_y
    ):

        self.game = game

        self.image = image

        self.rect = self.image.get_rect(
            center=(x, y)
        )

        self.velocity_x = velocity_x
        self.velocity_y = velocity_y

        self.rotation = 0
        self.rotation_speed = 12

        self.timer = 300

    def update(self):

        self.rect.x += self.velocity_x
        self.rect.y += self.velocity_y

        self.velocity_x *= 0.95
        self.velocity_y *= 0.95

        self.rotation += self.rotation_speed

        self.timer -= 1

    def draw(self):

        rotated = pygame.transform.rotate(
            self.image,
            self.rotation
        )

        rect = rotated.get_rect(
            center=self.rect.center
        )

        self.game.game_surface.blit(
            rotated,
            self.game.camera.apply(rect)
        )